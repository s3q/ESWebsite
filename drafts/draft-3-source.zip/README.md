# Engineering Society — Sultan Qaboos University · Draft 3

Landing page for the Engineering Society, built with Next.js (App Router, TypeScript), GSAP and
React Three Fiber. Earlier drafts are kept:

- **Draft 1** (Vite): the sibling folder `../ES`, untouched.
- **Draft 2** (Next.js): `drafts/draft-2-source.zip`, the full source before this refinement.

Product scope comes from `PRD.pdf` (Idea & Requirements Document v1.0). This is the public
landing page only: no backend, authentication or admin tools.

## Run

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # production build (includes type checking)
npm start          # serve the production build
npm run lint
npm run typecheck
```

## Page

One route, `/`. Sections in order: `#events` → `#projects` → `#disciplines`, then `#join`
(closing invitation) and the footer. `#top` is the hero. Draft 1's `#activities` anchor lands
on Events.

## What is real and what is a preview

| Area | State | Where to change it |
| --- | --- | --- |
| Events | **Sample listings**, each labelled "Sample". "Preview registration" opens an explanatory dialog; nothing is submitted. | `content/events.ts` |
| Projects | **Sample archive entries**. The discipline filter really filters them. No detail pages exist yet (`href: null`); set `href` and the whole piece becomes a link. | `content/projects.ts` |
| Imagery | Subject-specific technical drawings, not photos. Add `image: { src, alt, width, height }` to any event or project and the photo replaces the drawing. | `content/events.ts`, `content/projects.ts`, `components/ui/drawings.tsx` |
| Disciplines | The seven disciplines from Draft 1's content. This is not an official SQU department list. | `content/disciplines.ts` |
| Membership | No registration flow exists yet. "Join the Society" leads to `#join` and a preview dialog. | `content/site.ts` → `membershipUrl` |
| Social accounts | **None configured.** The "Follow the Society" area appears automatically once at least one valid profile URL is set. | `content/social.ts` |

Social URLs are validated: they must use https, sit on the platform's own domain and point to a
profile path. A bare platform homepage is rejected.

## Hero sculpture

A live Three.js scene (`components/hero/emblem/`) derived from the society's four-part logo.
Four leaf-shaped modules, each an ivory body on a satin-metal plate, carry the logo's
symbols in relief: derrick, aqueduct span, circuit traces and gear. The official logo file
itself is never altered.

- **Desktop:** the hero is one viewport taller than its sticky stage. A single scrubbed GSAP
  timeline runs as you scroll: the camera shifts while the modules square up, then they connect
  into the emblem (the gear turns as it seats), and the completed sculpture settles as Events
  arrives. It is fully reversible. Native scrolling is never intercepted. Pointer tilt is capped
  at ±4° on a separate group.
- **Mobile and tablet:** a compact scene below the copy, with a shorter sequence: no pinning, no
  camera move, no rotations, lighter geometry, and no shadow maps.
- **Loading:** the 3D code loads only when the artwork is near the viewport and the browser is
  idle. Canvas resolution is capped (2× desktop, 1.5× mobile). Frames render on demand and pause
  offscreen or in a hidden tab.
- **Stills:** `public/hero/emblem-opening.webp` shows at first paint on desktop, and the live
  canvas crossfades over it. `emblem-assembled.webp` is the reduced-motion, Save-Data and
  no-WebGL composition; reduced-motion visitors never download the 3D code. Both are renders of
  the real scene. Regenerate them with `scripts/capture-still.mjs` after changing the geometry.

## Motion

One vocabulary in `lib/motion.ts` (mirrored in `styles/tokens.css`), with recipes chosen by purpose
rather than one repeated fade (`components/motion/ScrollReveals.tsx`):

- **Headings:** rise.
- **Events:** a coordinated reveal (the drawing unmasks, the date lifts in, the text follows),
  then schedule rules draw across as each row slides in.
- **Projects:** image-mask reveals, a small desktop parallax inside the drawings, and a tilt of
  at most 2.5° on fine pointers (`ProjectsBrowser.tsx`).
- **Disciplines:** rules draw while each symbol settles. On hover or focus, one detail moves in
  each symbol.
- **Closing band:** the colour key draws left to right.

Everything plays once, respects reduced motion, and leaves content visible without JavaScript.

## Structure

```
app/                 layout, page, favicon, dev-only /dev/emblem capture route
components/
  hero/              Hero (server), HeroArt (client loader, stills, fallbacks)
    emblem/          EmblemScene (R3F + GSAP timeline), geometry
  layout/            SiteHeader, SiteFooter (incl. Follow the Society)
  sections/          Events, Projects (+ ProjectsBrowser), Disciplines, JoinInvitation
  motion/            ScrollReveals
  ui/                drawings, Plate/ItemMedia, DisciplineSymbol, SocialIcon, PreviewAction, icons
content/             all copy and data: site, events, projects, disciplines, social, media
lib/                 motion constants, formatting, media-query + WebGL helpers
styles/              tokens.css, globals.css
```

## Design skills

Installed at project scope in `.claude/skills` (see `skills-lock.json`): Emil Kowalski's
skills, Hallmark, and UI UX Pro Max. The stamp at the top of `styles/tokens.css` and
`.hallmark/log.json` record the design choices.
