import { Hero } from '@/components/hero/Hero'
import { SiteFooter } from '@/components/layout/SiteFooter'
import { SiteHeader } from '@/components/layout/SiteHeader'
import { ScrollReveals } from '@/components/motion/ScrollReveals'
import { Disciplines } from '@/components/sections/Disciplines'
import { Events } from '@/components/sections/Events'
import { JoinInvitation } from '@/components/sections/JoinInvitation'
import { Projects } from '@/components/sections/Projects'

export default function HomePage() {
  return (
    <>
      <SiteHeader />
      <main id="main" tabIndex={-1}>
        <Hero />
        <Events />
        <Projects />
        <Disciplines />
        <JoinInvitation />
      </main>
      <SiteFooter />
      <ScrollReveals />
    </>
  )
}
