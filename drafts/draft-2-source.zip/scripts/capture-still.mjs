// Regenerates public/hero/assembly-still.webp from the live 3D scene, so the reduced-motion
// and no-WebGL still always matches the WebGL render.
//
//   1. npm run dev            (the /dev/assembly route only exists in development)
//   2. node scripts/capture-still.mjs [pose=0]
//
// Needs playwright-core with a Chromium build. It is deliberately not a project dependency:
// point PLAYWRIGHT_PATH at an existing install, or run `npm i -D playwright-core` locally.
import { createRequire } from 'node:module'
import { writeFile } from 'node:fs/promises'

const require = createRequire(import.meta.url)
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright-core')
const pose = process.argv[2] ?? '0'
const base = process.env.URL || 'http://localhost:3000'

const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] })
const page = await browser.newPage({ viewport: { width: 700, height: 700 }, deviceScaleFactor: 2 })
await page.goto(`${base}/dev/assembly?pose=${pose}`, { waitUntil: 'networkidle' })
await page.waitForFunction(() => window.__assemblyReady === true, null, { timeout: 60000 })
await page.waitForTimeout(2500)
const png = await page.locator('#capture').screenshot({ omitBackground: true })
await browser.close()

try {
  const { default: sharp } = await import('sharp')
  await sharp(png).webp({ quality: 86, effort: 6 }).toFile('public/hero/assembly-still.webp')
  console.log('Wrote public/hero/assembly-still.webp')
} catch {
  await writeFile('assembly-still.png', png)
  console.log('sharp is unavailable: wrote assembly-still.png. Convert it to WebP at public/hero/assembly-still.webp.')
}
