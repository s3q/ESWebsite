'use client'

import dynamic from 'next/dynamic'
import { useEffect, useRef } from 'react'

const AssemblyScene = dynamic(() => import('@/components/hero/assembly/AssemblyScene'), { ssr: false })

const noop = () => {}

export function AssemblyCapture({ pose }: { pose: number }) {
  const activeRef = useRef(true)

  useEffect(() => {
    document.body.style.background = 'transparent'
  }, [])

  return (
    <div id="capture" style={{ width: 640, height: 640 }}>
      <AssemblyScene
        quality="high"
        ambient={false}
        activeRef={activeRef}
        sectionEl={null}
        artEl={null}
        onReady={noop}
        onError={noop}
        capturePose={pose}
      />
    </div>
  )
}
