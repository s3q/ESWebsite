import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { AssemblyCapture } from './AssemblyCapture'

export const metadata: Metadata = { robots: { index: false, follow: false } }

/**
 * Development-only route used by scripts/capture-still.mjs to render the hero assembly at a
 * fixed pose on a transparent background. The resulting image is the reduced-motion and
 * no-WebGL still, so it always matches the live scene. Returns 404 in production builds.
 */
export default async function AssemblyCapturePage({
  searchParams,
}: {
  searchParams: Promise<{ pose?: string }>
}) {
  if (process.env.NODE_ENV === 'production') notFound()
  const { pose = '0' } = await searchParams
  const value = Math.min(1, Math.max(0, Number(pose) || 0))
  return <AssemblyCapture pose={value} />
}
