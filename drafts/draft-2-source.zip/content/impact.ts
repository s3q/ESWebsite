/**
 * Long-term value of the platform, ordered by the PRD's phase plan (Part 3). Nothing here is
 * live yet: this site is a static preview. No statistics are shown because none have been
 * recorded; the PRD's "540 members attended 34 events" line is an illustration, not data.
 */

export type CapabilityStatus = 'first-release' | 'planned'

export interface ImpactPillar {
  phase: number
  title: string
  body: string
  status: CapabilityStatus
  useCases: string
}

export const IMPACT_PILLARS: ImpactPillar[] = [
  {
    phase: 1,
    title: 'Participation and learning',
    body: 'Committees publish workshops, talks and visits here, and members register on the same page. No separate forms, no links lost in group chats.',
    status: 'first-release',
    useCases: 'UC-01 · UC-02',
  },
  {
    phase: 2,
    title: 'Attendance and certificates',
    body: 'Check-in records who attended. Eligible attendees receive a verifiable certificate on their profile, with no request needed.',
    status: 'planned',
    useCases: 'UC-03 · UC-04',
  },
  {
    phase: 3,
    title: 'Projects and publications',
    body: 'Finished projects and magazine issues are tagged by project, year and team, then kept searchable for every cohort that follows.',
    status: 'planned',
    useCases: 'UC-05 · UC-06',
  },
  {
    phase: 4,
    title: 'Connections across cohorts',
    body: 'Graduates keep their full history and can opt in to a directory and mentorship with current members.',
    status: 'planned',
    useCases: 'UC-07',
  },
]

export const CAPABILITY_LABEL: Record<CapabilityStatus, string> = {
  'first-release': 'First release',
  planned: 'Planned',
}
