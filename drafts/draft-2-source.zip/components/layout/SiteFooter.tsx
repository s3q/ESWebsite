import Image from 'next/image'
import { SECTION_LINKS, SITE } from '@/content/site'
import styles from './SiteFooter.module.css'

export function SiteFooter() {
  const year = new Date().getFullYear()

  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.mast}>
          <div className={styles.identity}>
            <Image src="/brand/es-emblem.webp" alt="" width={64} height={64} className={styles.emblem} />
            <div>
              <p className={styles.name}>{SITE.name}</p>
              <p className={styles.tagline}>Discover events, share projects, preserve achievements.</p>
            </div>
          </div>
          <div className={styles.affiliation}>
            <p className={styles.affiliationLabel}>A student society at</p>
            {/* The wordmark keeps its original white field, colours and proportions. */}
            <div className={styles.wordmark}>
              <Image
                src="/brand/squ-wordmark.png"
                alt="Sultan Qaboos University"
                width={399}
                height={126}
                sizes="200px"
              />
            </div>
          </div>
        </div>

        <nav aria-label="Footer" className={styles.nav}>
          <ul className={styles.links}>
            {SECTION_LINKS.map((link) => (
              <li key={link.id}>
                <a href={link.href} className={styles.link}>
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          {SITE.contact.length > 0 && (
            <ul className={styles.links}>
              {SITE.contact.map((c) => (
                <li key={c.href}>
                  <a href={c.href} className={styles.link}>
                    {c.label}
                  </a>
                </li>
              ))}
            </ul>
          )}
        </nav>

        <div className={styles.base}>
          <p>
            © {year} {SITE.name}, {SITE.affiliation}.
          </p>
          <p>Preview site. Platform features arrive in phases.</p>
        </div>
      </div>
    </footer>
  )
}
