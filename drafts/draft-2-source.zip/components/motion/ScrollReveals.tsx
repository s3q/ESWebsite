'use client'

import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { MOTION } from '@/lib/motion'

gsap.registerPlugin(ScrollTrigger, useGSAP)

/**
 * The page's one scroll-reveal system. Sections opt in with data-reveal:
 *   heading      opacity + 24px rise
 *   quiet        opacity + 14px rise (Events/Projects content, supporting copy)
 *   group        children stagger 0.08s with the heading distance
 *   quiet-group  children stagger with the quiet distance
 *   rule         a hairline drawn with scaleX
 * Content is fully visible without JavaScript and under reduced motion: initial states are
 * only applied here, and only to elements that start below the fold.
 */
export function ScrollReveals() {
  useGSAP(() => {
    const mm = gsap.matchMedia()

    mm.add('(prefers-reduced-motion: no-preference)', () => {
      const threshold = window.innerHeight * 0.85
      gsap.utils.toArray<HTMLElement>('[data-reveal]').forEach((el) => {
        // Already on screen (e.g. reload mid-page): leave it alone rather than flash it hidden.
        if (el.getBoundingClientRect().top < threshold) return

        const kind = el.dataset.reveal ?? 'heading'
        const trigger = { trigger: el, start: MOTION.reveal.start, once: true }

        if (kind === 'rule') {
          gsap.from(el, {
            scaleX: 0,
            scaleY: 0,
            duration: 1.1,
            ease: MOTION.ease,
            clearProps: 'transform',
            scrollTrigger: trigger,
          })
          return
        }

        const quiet = kind.startsWith('quiet')
        const cfg = quiet ? MOTION.quiet : MOTION.reveal
        const targets = kind.endsWith('group') ? Array.from(el.children) : el

        gsap.from(targets, {
          opacity: 0,
          y: cfg.distance,
          duration: cfg.duration,
          ease: MOTION.ease,
          stagger: cfg.stagger,
          clearProps: 'opacity,transform',
          scrollTrigger: trigger,
        })
      })
    })

    // Trigger positions depend on final text metrics and image sizes.
    const refresh = () => ScrollTrigger.refresh()
    document.fonts?.ready.then(refresh).catch(() => {})
    window.addEventListener('load', refresh)

    return () => {
      window.removeEventListener('load', refresh)
      mm.revert()
    }
  })

  return null
}
