import { EVENTS, EVENT_TIMEZONE_LABEL, REGISTRATION_LABEL, type SocietyEvent } from '@/content/events'
import { eventDateParts, eventTimeRange } from '@/lib/format'
import { IconClock, IconPin } from '@/components/ui/icons'
import { Plate } from '@/components/ui/Plate'
import { PreviewAction } from '@/components/ui/PreviewAction'
import styles from './Events.module.css'

export function Events() {
  const [featured, ...rest] = EVENTS

  return (
    <section id="events" className="section" aria-labelledby="events-title">
      <div className="container">
        <header className="section-head">
          <h2 id="events-title" className="section-title" data-reveal="heading">
            Find your next experience.
          </h2>
          <div className={styles.headAside} data-reveal="quiet">
            <p className="section-lead">
              Workshops, talks and visits run by the society’s committees, with registration on the same page.
            </p>
            <p className="preview-note">
              <span className="status-dot" aria-hidden="true" />
              <span>
                <strong>Sample listings.</strong> No events have been published on the platform yet; these show how
                they will appear.
              </span>
            </p>
          </div>
        </header>

        {featured ? (
          <div className={styles.layout} data-reveal="quiet-group">
            <FeaturedEvent event={featured} />
            {rest.length > 0 && (
              <ol className={styles.list} aria-label="More events">
                {rest.map((event) => (
                  <li key={event.id}>
                    <EventRow event={event} />
                  </li>
                ))}
              </ol>
            )}
          </div>
        ) : (
          <p className={styles.empty}>
            No events are scheduled right now. New workshops and talks will appear here as committees publish them.
          </p>
        )}
      </div>
    </section>
  )
}

function Meta({ event }: { event: SocietyEvent }) {
  const date = eventDateParts(event.start)
  return (
    <dl className={styles.meta}>
      <div>
        <dt>
          <IconClock className={styles.metaIcon} />
          <span className="visually-hidden">Date and time</span>
        </dt>
        <dd>
          <time dateTime={event.start}>{date.long}</time>, {eventTimeRange(event.start, event.end)}{' '}
          <span className={styles.tz}>{EVENT_TIMEZONE_LABEL}</span>
        </dd>
      </div>
      <div>
        <dt>
          <IconPin className={styles.metaIcon} />
          <span className="visually-hidden">Location</span>
        </dt>
        <dd>{event.location}</dd>
      </div>
    </dl>
  )
}

function Register({ event, compact }: { event: SocietyEvent; compact?: boolean }) {
  return (
    <div className={styles.register}>
      <p className={styles.status}>
        <span className="status-dot" aria-hidden="true" />
        {REGISTRATION_LABEL[event.registration]}
      </p>
      <PreviewAction
        label="Preview registration"
        labelSuffix={event.title}
        variant={compact ? 'secondary' : 'primary'}
        compact
        title="Registration isn’t open yet"
        next={{ href: '#impact', label: 'See what’s planned' }}
      >
        <p>
          <strong>{event.title}</strong> is a sample listing. When event registration launches in Phase 1, you’ll
          register right here and see your confirmation instantly on the same page.
        </p>
        <p>Nothing has been submitted, and no place has been reserved.</p>
      </PreviewAction>
    </div>
  )
}

function FeaturedEvent({ event }: { event: SocietyEvent }) {
  const date = eventDateParts(event.start)
  return (
    <article className={styles.featured} aria-labelledby={`${event.id}-title`}>
      <div className={styles.media}>
        <Plate id={event.id} art={event.art} tone="soft" className={styles.plate} />
        {event.sample && <span className={`chip chip--sample ${styles.sampleTag}`}>Sample</span>}
      </div>
      <div className={styles.featuredBody}>
        <div className={styles.dateBlock} aria-hidden="true">
          <span className={styles.day}>{date.day}</span>
          <span className={styles.monthYear}>
            {date.month} {date.year}
            <span className={styles.weekday}>{date.weekday}</span>
          </span>
        </div>
        <div className={styles.featuredText}>
          <p className={styles.type}>{event.type}</p>
          <h3 id={`${event.id}-title`} className={styles.featuredTitle}>
            {event.title}
          </h3>
          <p className={styles.description}>{event.description}</p>
          <Meta event={event} />
          <Register event={event} />
        </div>
      </div>
    </article>
  )
}

function EventRow({ event }: { event: SocietyEvent }) {
  const date = eventDateParts(event.start)
  return (
    <article className={styles.row} aria-labelledby={`${event.id}-title`}>
      <div className={styles.rowDate} aria-hidden="true">
        <span className={styles.rowDay}>{date.day}</span>
        <span className={styles.rowMonth}>{date.month}</span>
      </div>
      <div className={styles.rowBody}>
        <p className={styles.type}>
          {event.type}
          {event.sample && <span className="chip chip--sample">Sample</span>}
        </p>
        <h3 id={`${event.id}-title`} className={styles.rowTitle}>
          {event.title}
        </h3>
        <p className={styles.description}>{event.description}</p>
        <Meta event={event} />
        <Register event={event} compact />
      </div>
    </article>
  )
}
