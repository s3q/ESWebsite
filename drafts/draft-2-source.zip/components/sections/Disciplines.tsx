import { DISCIPLINES } from '@/content/disciplines'
import { PROJECTS } from '@/content/projects'
import { LineArtIcon } from '@/components/ui/icons'
import { DisciplineProjectsLink } from './DisciplineProjectsLink'
import styles from './Disciplines.module.css'

export function Disciplines() {
  // An action appears only where it leads somewhere real: a discipline with archive entries.
  const withProjects = new Set(PROJECTS.map((p) => p.discipline))

  return (
    <section id="disciplines" className="section" aria-labelledby="disciplines-title">
      <div className="container">
        <header className="section-head">
          <h2 id="disciplines-title" className="section-title" data-reveal="heading">
            Different disciplines. Shared ambition.
          </h2>
          <p className="section-lead" data-reveal="quiet">
            Seven engineering disciplines meet in one society: the same events, the same archive and the same
            network, whichever field you study.
          </p>
        </header>

        <ul className={styles.grid} data-reveal="group">
          {DISCIPLINES.map((d) => (
            <li key={d.id} className={styles.row}>
              <span className={styles.icon} aria-hidden="true">
                <LineArtIcon art={d.id} width={24} height={24} />
              </span>
              <div className={styles.text}>
                <h3 className={styles.name}>{d.name}</h3>
                <p className={styles.focus}>{d.focus}</p>
                <p className={styles.description}>{d.description}</p>
              </div>
              {withProjects.has(d.id) && (
                <DisciplineProjectsLink discipline={d.id} name={d.shortName} className={styles.action} />
              )}
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
