'use client'

import { useEffect, useMemo, useState } from 'react'
import { DISCIPLINE_BY_ID, type DisciplineId } from '@/content/disciplines'
import type { ArchiveProject } from '@/content/projects'
import { IconArchive, IconTeam } from '@/components/ui/icons'
import { Plate } from '@/components/ui/Plate'
import { PROJECT_FILTER_EVENT } from '@/lib/events'
import styles from './Projects.module.css'

type Filter = DisciplineId | 'all'

export function ProjectsBrowser({ projects }: { projects: ArchiveProject[] }) {
  const [filter, setFilter] = useState<Filter>('all')

  // Discipline rows elsewhere on the page can pre-select a filter.
  useEffect(() => {
    const onFilter = (e: Event) => {
      const id = (e as CustomEvent<DisciplineId>).detail
      if (id && id in DISCIPLINE_BY_ID) setFilter(id)
    }
    window.addEventListener(PROJECT_FILTER_EVENT, onFilter)
    return () => window.removeEventListener(PROJECT_FILTER_EVENT, onFilter)
  }, [])

  // Only disciplines that actually have entries get a filter, in first-appearance order.
  const disciplines = useMemo(() => [...new Set(projects.map((p) => p.discipline))], [projects])
  const visible = filter === 'all' ? projects : projects.filter((p) => p.discipline === filter)
  const [featured, ...others] = visible
  const supporting = others.slice(0, 2)
  const more = others.slice(2)

  const summary =
    filter === 'all'
      ? `Showing all ${visible.length} sample projects`
      : `Showing ${visible.length} sample ${visible.length === 1 ? 'project' : 'projects'} in ${DISCIPLINE_BY_ID[filter].name}`

  return (
    <div className={styles.browser}>
      <div className={styles.filters} role="group" aria-label="Filter projects by discipline">
        <FilterButton active={filter === 'all'} onClick={() => setFilter('all')}>
          All
        </FilterButton>
        {disciplines.map((id) => (
          <FilterButton key={id} active={filter === id} onClick={() => setFilter(id)}>
            {DISCIPLINE_BY_ID[id].shortName}
          </FilterButton>
        ))}
      </div>
      <p className="visually-hidden" aria-live="polite">
        {summary}
      </p>

      <div key={filter} className={styles.results}>
        {featured && <FeaturedProject project={featured} />}

        {supporting.length > 0 && (
          <ul className={styles.supporting}>
            {supporting.map((p) => (
              <li key={p.id}>
                <ProjectCard project={p} />
              </li>
            ))}
          </ul>
        )}

        {more.length > 0 && (
          <div className={styles.more}>
            <h3 className={styles.moreTitle}>Also in the archive</h3>
            <ul className={styles.moreList}>
              {more.map((p) => (
                <li key={p.id} className={styles.moreRow}>
                  <span className={styles.moreName}>{p.title}</span>
                  <span className={styles.moreMeta}>
                    {DISCIPLINE_BY_ID[p.discipline].shortName} · {p.year}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {filter !== 'all' && visible.length === 1 && (
          <p className={styles.note}>This is the only sample project in this discipline.</p>
        )}
      </div>
    </div>
  )
}

function FilterButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: string }) {
  return (
    <button type="button" className={styles.filter} aria-pressed={active} onClick={onClick}>
      {children}
    </button>
  )
}

function ProjectMeta({ project }: { project: ArchiveProject }) {
  return (
    <dl className={styles.meta}>
      <div>
        <dt>Discipline</dt>
        <dd>{DISCIPLINE_BY_ID[project.discipline].shortName}</dd>
      </div>
      <div>
        <dt>Year</dt>
        <dd>{project.year}</dd>
      </div>
      <div>
        <dt>Team</dt>
        <dd>
          <IconTeam className={styles.teamIcon} />
          {project.team}
        </dd>
      </div>
    </dl>
  )
}

function ArchiveStatus({ project }: { project: ArchiveProject }) {
  if (project.href) {
    return (
      <a href={project.href} className="btn btn--secondary btn--compact">
        View project
      </a>
    )
  }
  return (
    <p className={styles.archiveStatus}>
      <IconArchive className={styles.archiveIcon} />
      Full archive entry opens in Phase 3
    </p>
  )
}

function FeaturedProject({ project }: { project: ArchiveProject }) {
  return (
    <article className={styles.featured} aria-labelledby={`${project.id}-title`}>
      <div className={styles.featuredMedia}>
        <Plate id={project.id} art={project.art} tone="brand" scale={8.4} className={styles.plate} />
        {project.sample && <span className={`chip chip--sample ${styles.sampleTag}`}>Sample</span>}
      </div>
      <div className={styles.featuredBody}>
        <h3 id={`${project.id}-title`} className={styles.featuredTitle}>
          {project.title}
        </h3>
        <p className={styles.summary}>{project.summary}</p>
        <ProjectMeta project={project} />
        <ArchiveStatus project={project} />
      </div>
    </article>
  )
}

function ProjectCard({ project }: { project: ArchiveProject }) {
  return (
    <article className={styles.card} aria-labelledby={`${project.id}-title`}>
      <div className={styles.cardMedia}>
        <Plate id={project.id} art={project.art} tone="soft" className={styles.plate} />
        {project.sample && <span className={`chip chip--sample ${styles.sampleTag}`}>Sample</span>}
      </div>
      <div className={styles.cardBody}>
        <h3 id={`${project.id}-title`} className={styles.cardTitle}>
          {project.title}
        </h3>
        <p className={styles.summary}>{project.summary}</p>
        <ProjectMeta project={project} />
      </div>
    </article>
  )
}
