import { CAPABILITY_LABEL, IMPACT_PILLARS } from '@/content/impact'
import styles from './Impact.module.css'

export function Impact() {
  return (
    <section id="impact" className={`section ${styles.impact}`} aria-labelledby="impact-title">
      <div className="container">
        <header className={`section-head ${styles.head}`}>
          <h2 id="impact-title" className={`section-title ${styles.title}`} data-reveal="heading">
            Experiences that stay with you.
          </h2>
          <p className={styles.lead} data-reveal="quiet">
            The platform is built on one promise: nothing a member does should be lost. Events, certificates and
            projects attach to one permanent profile that carries forward, from first year to graduation and beyond.
          </p>
        </header>

        <div className={styles.timeline}>
          <span className={styles.track} aria-hidden="true" data-reveal="rule" />
          <ol className={styles.pillars} data-reveal="group">
            {IMPACT_PILLARS.map((pillar) => (
              <li key={pillar.phase} className={styles.pillar}>
                <span className={styles.node} data-status={pillar.status} aria-hidden="true" />
                <p className={styles.phase}>
                  Phase {pillar.phase}
                  <span className={styles.status} data-status={pillar.status}>
                    {CAPABILITY_LABEL[pillar.status]}
                  </span>
                </p>
                <h3 className={styles.pillarTitle}>{pillar.title}</h3>
                <p className={styles.body}>{pillar.body}</p>
                <p className={styles.useCases}>
                  <span className="visually-hidden">Requirement references: </span>
                  {pillar.useCases}
                </p>
              </li>
            ))}
          </ol>
        </div>

        <p className={styles.footnote} data-reveal="quiet">
          <strong>Where things stand:</strong> this site previews the platform, and none of these features are live
          yet. Figures such as attendance and membership will appear here, with their reporting period, once the
          platform has recorded them.
        </p>
      </div>
    </section>
  )
}
