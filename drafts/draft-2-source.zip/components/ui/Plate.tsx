import { ART, type PlateArt } from './art'
import styles from './Plate.module.css'

export type { PlateArt }

type PlateTone = 'soft' | 'brand' | 'ivory'

interface PlateProps {
  /** Stable, unique id — used for the SVG grid pattern reference. */
  id: string
  art: PlateArt
  tone?: PlateTone
  /** Art scale relative to the 24-unit grid. */
  scale?: number
  className?: string
}

const W = 480
const H = 300

/**
 * A drafting plate: a quiet technical drawing on a grid, standing in for photography until
 * authentic society images exist. Purely illustrative, so it is hidden from assistive tech;
 * the surrounding card carries all information.
 */
export function Plate({ id, art, tone = 'soft', scale = 7.4, className }: PlateProps) {
  const def = ART[art]
  const size = 24 * scale
  const ox = W / 2 - size / 2
  const oy = H / 2 - size / 2 - 6
  const [sx, sy] = def.spark
  const sparkX = ox + sx * scale
  const sparkY = oy + sy * scale
  const dimY = oy + size + 22
  const patternId = `plate-grid-${id}`

  return (
    <div className={[styles.plate, styles[tone], className].filter(Boolean).join(' ')} aria-hidden="true">
      <svg className={styles.svg} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid slice" focusable="false">
        <defs>
          <pattern id={patternId} width="24" height="24" patternUnits="userSpaceOnUse">
            <path d="M24 0H0V24" className={styles.gridMinor} />
          </pattern>
        </defs>
        <rect width={W} height={H} fill={`url(#${patternId})`} />

        {/* Drawing border with registration ticks */}
        <rect x="16" y="16" width={W - 32} height={H - 32} className={styles.border} />
        <path
          d={`M16 ${H / 2}h10M${W - 16} ${H / 2}h-10M${W / 2} 16v10M${W / 2} ${H - 16}v-10`}
          className={styles.border}
        />

        {/* Centre lines */}
        <path d={`M${ox - 28} ${sparkY}H${ox + size + 28}M${sparkX} ${oy - 20}V${oy + size + 8}`} className={styles.centerline} />

        {/* The drawing */}
        <g transform={`translate(${ox} ${oy}) scale(${scale})`} className={styles.art}>
          {def.body}
        </g>

        {/* Dimension line */}
        <path
          d={`M${ox} ${dimY}H${ox + size}M${ox} ${dimY - 6}v12M${ox + size} ${dimY - 6}v12`}
          className={styles.dimension}
        />

        {/* Gold detail at the drawing's key joint */}
        <circle cx={sparkX} cy={sparkY} r="15" className={styles.callout} />
        <circle cx={sparkX} cy={sparkY} r="4.5" className={styles.spark} />
      </svg>
    </div>
  )
}
