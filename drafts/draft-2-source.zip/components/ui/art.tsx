import type { ReactNode } from 'react'

/**
 * One line-art family on a 24-unit grid. The same drawings render as 24px discipline icons
 * and, scaled up with non-scaling strokes, as the drafting plates used for event and project
 * imagery. `spark` marks the joint that receives the small gold detail on plates, echoing
 * the gold element of the hero assembly.
 */

export type PlateArt =
  | 'mechanical'
  | 'electrical'
  | 'civil'
  | 'petroleum'
  | 'chemical'
  | 'mechatronics'
  | 'industrial'
  | 'network'
  | 'rover'

interface ArtDefinition {
  body: ReactNode
  spark: [number, number]
}

function gearPath(cx: number, cy: number, outerR: number, rootR: number, teeth: number) {
  const step = (Math.PI * 2) / teeth
  const halfTop = step * 0.24
  const halfBase = step * 0.34
  let d = ''
  for (let i = 0; i < teeth; i++) {
    const c = i * step - Math.PI / 2
    const pts = [
      [rootR, c - halfBase],
      [outerR, c - halfTop],
      [outerR, c + halfTop],
      [rootR, c + halfBase],
    ]
    for (const [r, a] of pts) {
      d += `${d ? 'L' : 'M'}${(cx + r * Math.cos(a)).toFixed(2)},${(cy + r * Math.sin(a)).toFixed(2)}`
    }
  }
  return `${d}Z`
}

const GEAR = gearPath(12, 12, 9.2, 7, 9)

export const ART: Record<PlateArt, ArtDefinition> = {
  mechanical: {
    body: (
      <>
        <path d={GEAR} />
        <circle cx="12" cy="12" r="2.6" />
      </>
    ),
    spark: [12, 12],
  },
  electrical: {
    body: (
      <>
        <rect x="7" y="7" width="10" height="10" rx="1.6" />
        <rect x="10" y="10" width="4" height="4" rx="0.6" />
        <path d="M9.5 3.5V7M14.5 3.5V7M9.5 17v3.5M14.5 17v3.5M3.5 9.5H7M3.5 14.5H7M17 9.5h3.5M17 14.5h3.5" />
      </>
    ),
    spark: [12, 12],
  },
  civil: {
    body: (
      <>
        <path d="M2.5 16h19M6 10h12" />
        <path d="M3 16l3-6 3 6 3-6 3 6 3-6 3 6" />
        <path d="M5.5 16v4.5M18.5 16v4.5" />
      </>
    ),
    spark: [12, 10],
  },
  petroleum: {
    body: (
      <>
        <path d="M12 3L7 20M12 3l5 17" />
        <path d="M9.2 10h5.6M8.1 14.4h7.8M9.2 10l6.7 4.4M14.8 10l-6.7 4.4" />
        <path d="M4.5 20.5h15" />
      </>
    ),
    spark: [12, 3.6],
  },
  chemical: {
    body: (
      <>
        <path d="M9.4 3.2h5.2M10.2 3.2v5.6L5.6 17a2 2 0 001.8 3h9.2a2 2 0 001.8-3l-4.6-8.2V3.2" />
        <path d="M7.4 14.4h9.2" />
        <circle cx="10.4" cy="17" r="0.9" />
      </>
    ),
    spark: [13.8, 16.6],
  },
  mechatronics: {
    body: (
      <>
        <path d="M4.5 20.5h8M8.5 20.5v-3" />
        <circle cx="8.5" cy="16" r="1.5" />
        <path d="M9.3 14.7l3.2-4.9" />
        <circle cx="13.3" cy="8.5" r="1.5" />
        <path d="M14.7 9.1l3.9 2.3M18.6 11.4l2-1.1M18.6 11.4l1 2" />
      </>
    ),
    spark: [13.3, 8.5],
  },
  industrial: {
    body: (
      <>
        <rect x="3" y="13" width="18" height="5" rx="2.5" />
        <circle cx="5.6" cy="15.5" r="1" />
        <circle cx="18.4" cy="15.5" r="1" />
        <rect x="6" y="7.5" width="4.5" height="4.5" rx="0.8" />
        <rect x="12.5" y="8.5" width="3.5" height="3.5" rx="0.7" />
        <path d="M7.5 18v2.5M16.5 18v2.5" />
      </>
    ),
    spark: [14.25, 10.25],
  },
  network: {
    body: (
      <>
        <circle cx="12" cy="5.4" r="2.2" />
        <circle cx="5.4" cy="18" r="2.2" />
        <circle cx="18.6" cy="18" r="2.2" />
        <path d="M12 7.6V12m0 0l-5 4.2m5-4.2l5 4.2" />
      </>
    ),
    spark: [12, 12],
  },
  rover: {
    body: (
      <>
        <rect x="4" y="9" width="16" height="6" rx="1.5" />
        <circle cx="7.6" cy="16.6" r="2.2" />
        <circle cx="16.4" cy="16.6" r="2.2" />
        <path d="M16.5 9V6.4h2.6M2.5 20.5h19" />
      </>
    ),
    spark: [19.1, 6.4],
  },
}
