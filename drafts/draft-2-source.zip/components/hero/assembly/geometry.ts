import * as THREE from 'three'
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js'

/**
 * Procedural parts for the hero assembly. Everything shares one axis (local +Z) so the
 * exploded view reads like an engineering drawing: plate → flange ring → hex connector → pin.
 * All dimensions are in world units; see PART_LAYOUT for how the parts seat together.
 */

export type Quality = 'high' | 'low'

const detail = (q: Quality) => ({
  curve: q === 'high' ? 72 : 32,
  ring: q === 'high' ? 112 : 48,
  bevel: q === 'high' ? 5 : 2,
  lathe: q === 'high' ? 64 : 28,
})

function roundedRect(w: number, h: number, r: number) {
  const x = -w / 2
  const y = -h / 2
  const s = new THREE.Shape()
  s.moveTo(x + r, y)
  s.lineTo(x + w - r, y)
  s.absarc(x + w - r, y + r, r, -Math.PI / 2, 0, false)
  s.lineTo(x + w, y + h - r)
  s.absarc(x + w - r, y + h - r, r, 0, Math.PI / 2, false)
  s.lineTo(x + r, y + h)
  s.absarc(x + r, y + h - r, r, Math.PI / 2, Math.PI, false)
  s.lineTo(x, y + r)
  s.absarc(x + r, y + r, r, Math.PI, Math.PI * 1.5, false)
  return s
}

function hole(x: number, y: number, r: number) {
  const p = new THREE.Path()
  p.absarc(x, y, r, 0, Math.PI * 2, true)
  return p
}

/** Smooth curved walls and bevels while keeping flat faces flat. */
function smooth(geometry: THREE.BufferGeometry) {
  geometry.deleteAttribute('normal')
  const merged = mergeVertices(geometry, 1e-4)
  merged.computeVertexNormals()
  geometry.dispose()
  return merged
}

/** Ivory structural plate: rounded square with a central bore and four fixing holes. */
export function createFrame(q: Quality) {
  const d = detail(q)
  const shape = roundedRect(2.6, 2.6, 0.44)
  shape.holes.push(hole(0, 0, 0.66))
  for (const [x, y] of [
    [-0.92, -0.92],
    [0.92, -0.92],
    [0.92, 0.92],
    [-0.92, 0.92],
  ]) {
    shape.holes.push(hole(x, y, 0.1))
  }
  const depth = 0.3
  const g = new THREE.ExtrudeGeometry(shape, {
    depth,
    curveSegments: d.curve,
    bevelEnabled: true,
    bevelThickness: 0.05,
    bevelSize: 0.05,
    bevelSegments: d.bevel,
  })
  g.translate(0, 0, -depth / 2)
  return smooth(g)
}

/** Cobalt flange ring with a six-hole bolt circle, so its rotation stays legible. */
export function createRing(q: Quality) {
  const d = detail(q)
  const shape = new THREE.Shape()
  shape.absarc(0, 0, 1.08, 0, Math.PI * 2, false)
  shape.holes.push(hole(0, 0, 0.68))
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + Math.PI / 6
    shape.holes.push(hole(Math.cos(a) * 0.88, Math.sin(a) * 0.88, 0.075))
  }
  const depth = 0.22
  const g = new THREE.ExtrudeGeometry(shape, {
    depth,
    curveSegments: d.ring,
    bevelEnabled: true,
    bevelThickness: 0.04,
    bevelSize: 0.035,
    bevelSegments: d.bevel,
  })
  g.translate(0, 0, -depth / 2)
  return smooth(g)
}

/** Brushed-steel hex collar; back face at z = 0. Flat shading keeps the hex crisp. */
export function createCollar(q: Quality) {
  const d = detail(q)
  const shape = new THREE.Shape()
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2
    const x = Math.cos(a) * 0.8
    const y = Math.sin(a) * 0.8
    if (i === 0) shape.moveTo(x, y)
    else shape.lineTo(x, y)
  }
  shape.closePath()
  shape.holes.push(hole(0, 0, 0.23))
  const depth = 0.16
  const g = new THREE.ExtrudeGeometry(shape, {
    depth,
    curveSegments: d.curve,
    bevelEnabled: true,
    bevelThickness: 0.03,
    bevelSize: 0.03,
    bevelSegments: Math.max(2, d.bevel - 2),
  })
  g.translate(0, 0, 0.03)
  return g
}

/** Sleeve that passes through the ring and plate; front face at z ≈ 0. */
export function createSleeve(q: Quality) {
  const d = detail(q)
  const shape = new THREE.Shape()
  shape.absarc(0, 0, 0.58, 0, Math.PI * 2, false)
  shape.holes.push(hole(0, 0, 0.23))
  const depth = 1
  const g = new THREE.ExtrudeGeometry(shape, {
    depth,
    curveSegments: d.ring,
    bevelEnabled: true,
    bevelThickness: 0.025,
    bevelSize: 0.02,
    bevelSegments: Math.max(2, d.bevel - 2),
  })
  g.translate(0, 0, -1.02)
  return smooth(g)
}

/** Small gold pin with chamfered ends, turned about its axis. Back at −0.4, tip at +0.22. */
export function createPin(q: Quality) {
  const d = detail(q)
  const c = 0.035
  const r = 0.2
  const points = [
    new THREE.Vector2(0, -0.4),
    new THREE.Vector2(r - c, -0.4),
    new THREE.Vector2(r, -0.4 + c),
    new THREE.Vector2(r, 0.22 - c * 1.6),
    new THREE.Vector2(r - c * 1.6, 0.22),
    new THREE.Vector2(0, 0.22),
  ]
  const g = new THREE.LatheGeometry(points, d.lathe)
  g.rotateX(Math.PI / 2)
  return g
}

/**
 * Seated (assembled) and exploded positions along the shared axis. The container shift keeps
 * the composition centred in both states.
 */
export const PART_LAYOUT = {
  frame: { seated: 0, exploded: -0.4 },
  ring: { seated: 0.35, exploded: 1.42, spin: -0.8 },
  connector: { seated: 0.5, exploded: 3.1, spin: 0.9 },
  pin: { seated: 0.72, exploded: 4.12 },
  shift: { seated: -0.2, exploded: -1.86 },
  axis: { from: -1.2, to: 4.72 },
} as const

/** Fine directional streaks used as a roughness map for the brushed steel. */
export function createBrushedTexture() {
  if (typeof document === 'undefined') return null
  const canvas = document.createElement('canvas')
  canvas.width = 256
  canvas.height = 256
  const ctx = canvas.getContext('2d')
  if (!ctx) return null
  ctx.fillStyle = 'rgb(128,128,128)'
  ctx.fillRect(0, 0, 256, 256)
  let seed = 7
  const rand = () => {
    seed = (seed * 16807) % 2147483647
    return seed / 2147483647
  }
  for (let i = 0; i < 900; i++) {
    const y = rand() * 256
    const shade = 90 + rand() * 90
    ctx.strokeStyle = `rgba(${shade},${shade},${shade},${0.25 + rand() * 0.35})`
    ctx.lineWidth = 0.5 + rand() * 0.8
    ctx.beginPath()
    ctx.moveTo(0, y)
    ctx.lineTo(256, y + (rand() - 0.5) * 2)
    ctx.stroke()
  }
  const texture = new THREE.CanvasTexture(canvas)
  texture.wrapS = THREE.RepeatWrapping
  texture.wrapT = THREE.RepeatWrapping
  texture.repeat.set(1.4, 1.4)
  texture.anisotropy = 4
  return texture
}
