'use client'

import { ContactShadows, Environment, Lightformer, Line } from '@react-three/drei'
import { Canvas, useThree } from '@react-three/fiber'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useEffect, useMemo, useRef, type ComponentRef, type RefObject } from 'react'
import * as THREE from 'three'
import { DESKTOP_QUERY, MOTION, STACKED_QUERY } from '@/lib/motion'
import {
  PART_LAYOUT,
  createBrushedTexture,
  createCollar,
  createFrame,
  createPin,
  createRing,
  createSleeve,
  type Quality,
} from './geometry'

gsap.registerPlugin(ScrollTrigger, useGSAP)

/** Three-quarter view that lays the shared axis across the frame, like an exploded drawing. */
const ORIENTATION: [number, number, number] = [0.3, -0.98, 0]
const COMPOSITION = { width: 6.2, height: 4.1 }
const AXIS_OPACITY = 0.5
/** The seated assembly is compact, so it comes forward slightly as it completes. */
const SEATED_SCALE = 1.22

export interface AssemblySceneProps {
  quality: Quality
  /** Pointer tilt + breathing (fine-pointer desktops only). */
  ambient: boolean
  /** Whether the canvas is on screen and the tab is visible. */
  activeRef: RefObject<boolean>
  /** Hero section: drives the scroll choreography. */
  sectionEl: HTMLElement | null
  /** Artwork frame: drives the choreography on stacked (mobile) layouts. */
  artEl: HTMLElement | null
  onReady: () => void
  onError: () => void
  /** Capture mode renders one fixed pose (0 = exploded, 1 = seated) for the still image. */
  capturePose?: number
}

export default function AssemblyScene(props: AssemblySceneProps) {
  const { quality, capturePose, onError } = props
  const capture = capturePose !== undefined

  return (
    <Canvas
      frameloop="demand"
      dpr={[1, quality === 'high' ? 2 : 1.5]}
      gl={{
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
        preserveDrawingBuffer: capture,
      }}
      camera={{ fov: 28, position: [0, 0.35, 13], near: 0.1, far: 60 }}
      style={{ pointerEvents: 'none' }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.NeutralToneMapping
        gl.toneMappingExposure = 1.02
        gl.setClearColor(0x000000, 0)
        gl.domElement.addEventListener('webglcontextlost', (e) => {
          e.preventDefault()
          onError()
        })
      }}
    >
      <StudioLighting quality={quality} />
      <Assembly {...props} capture={capture} />
    </Canvas>
  )
}

function StudioLighting({ quality }: { quality: Quality }) {
  return (
    <>
      <ambientLight intensity={0.28} />
      <directionalLight position={[-3.5, 5, 4]} intensity={1.5} />
      <directionalLight position={[4, -1.5, 3]} intensity={0.35} color="#fff4e0" />
      {/* Soft studio reflections from in-scene light panels: no HDR download, rendered once. */}
      <Environment resolution={quality === 'high' ? 256 : 128} frames={1}>
        <Lightformer form="rect" intensity={2.1} position={[0, 5, 2]} rotation-x={Math.PI / 2} scale={[10, 4, 1]} />
        <Lightformer form="rect" intensity={1.3} position={[-6, 1, 3]} rotation-y={Math.PI / 2} scale={[6, 2.5, 1]} />
        <Lightformer form="rect" intensity={0.7} color="#fff1d6" position={[6, 0.5, 2]} rotation-y={-Math.PI / 2} scale={[5, 3, 1]} />
        <Lightformer form="ring" intensity={0.8} color="#e8eeff" position={[0, 1, -7]} scale={4} />
        {/* A soft grey studio backdrop, so metals reflect a room rather than a void. */}
        <color attach="background" args={['#b9bec7']} />
      </Environment>
      <ContactShadows
        position={[0, -2.05, 0]}
        opacity={0.3}
        scale={10}
        blur={2.8}
        far={3.4}
        resolution={quality === 'high' ? 512 : 256}
        color="#13233c"
      />
    </>
  )
}

function Assembly({
  quality,
  ambient,
  activeRef,
  sectionEl,
  artEl,
  onReady,
  capture,
  capturePose,
}: AssemblySceneProps & { capture: boolean }) {
  const invalidate = useThree((s) => s.invalidate)
  const size = useThree((s) => s.size)
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera

  // Parent groups own separate channels so tweens never compete for a property.
  const scrollGroup = useRef<THREE.Group>(null)
  const pointerGroup = useRef<THREE.Group>(null)
  const introGroup = useRef<THREE.Group>(null)
  const breathGroup = useRef<THREE.Group>(null)
  const orientGroup = useRef<THREE.Group>(null)
  const shiftGroup = useRef<THREE.Group>(null)
  const frame = useRef<THREE.Mesh>(null)
  const ring = useRef<THREE.Mesh>(null)
  const connector = useRef<THREE.Group>(null)
  const pin = useRef<THREE.Mesh>(null)
  const axis = useRef<ComponentRef<typeof Line>>(null)

  const parts = useMemo(
    () => ({
      frame: createFrame(quality),
      ring: createRing(quality),
      collar: createCollar(quality),
      sleeve: createSleeve(quality),
      pin: createPin(quality),
    }),
    [quality],
  )

  const materials = useMemo(() => {
    const brushed = quality === 'high' ? createBrushedTexture() : null
    return {
      brushed,
      ivory: new THREE.MeshPhysicalMaterial({
        color: '#eeeadf',
        roughness: 0.5,
        metalness: 0,
        clearcoat: 0.3,
        clearcoatRoughness: 0.45,
      }),
      cobalt: new THREE.MeshPhysicalMaterial({
        color: '#234bc4',
        roughness: 0.3,
        metalness: 0.3,
        clearcoat: 0.55,
        clearcoatRoughness: 0.28,
      }),
      steel: new THREE.MeshPhysicalMaterial({
        color: '#c5cbd4',
        roughness: 0.36,
        metalness: 1,
        roughnessMap: brushed,
      }),
      gold: new THREE.MeshPhysicalMaterial({
        color: '#cba326',
        roughness: 0.26,
        metalness: 1,
        clearcoat: 0.2,
      }),
    }
  }, [quality])

  useEffect(
    () => () => {
      Object.values(parts).forEach((g) => g.dispose())
      const { brushed, ...mats } = materials
      Object.values(mats).forEach((m) => m.dispose())
      brushed?.dispose()
    },
    [parts, materials],
  )

  // Fit the composition to the canvas at any aspect ratio.
  const fit = useMemo(() => {
    const distance = camera.position.length()
    const visibleH = 2 * distance * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2))
    const visibleW = visibleH * (size.width / Math.max(size.height, 1))
    return Math.min(1.08, visibleW / COMPOSITION.width, visibleH / COMPOSITION.height)
  }, [camera, size.width, size.height])

  useEffect(() => invalidate(), [fit, invalidate])

  // Signal readiness after the first frames have been drawn.
  useEffect(() => {
    let raf2 = 0
    const raf1 = requestAnimationFrame(() => {
      raf2 = requestAnimationFrame(() => {
        if (capture) (window as unknown as { __assemblyReady?: boolean }).__assemblyReady = true
        onReady()
      })
    })
    return () => {
      cancelAnimationFrame(raf1)
      cancelAnimationFrame(raf2)
    }
  }, [capture, onReady])

  useGSAP(
    () => {
      const f = frame.current
      const r = ring.current
      const c = connector.current
      const p = pin.current
      const shift = shiftGroup.current
      const orient = orientGroup.current
      const axisMaterial = axis.current?.material as THREE.Material | undefined
      if (!f || !r || !c || !p || !shift || !orient || !scrollGroup.current) return

      const L = PART_LAYOUT
      const pose = (t: number) => {
        const lerp = THREE.MathUtils.lerp
        f.position.z = lerp(L.frame.exploded, L.frame.seated, t)
        r.position.z = lerp(L.ring.exploded, L.ring.seated, t)
        r.rotation.z = lerp(L.ring.spin, 0, t)
        c.position.z = lerp(L.connector.exploded, L.connector.seated, t)
        c.rotation.z = lerp(L.connector.spin, 0, t)
        p.position.z = lerp(L.pin.exploded, L.pin.seated, t)
        shift.position.z = lerp(L.shift.exploded, L.shift.seated, t)
        orient.scale.setScalar(lerp(1, SEATED_SCALE, t))
        if (axisMaterial) axisMaterial.opacity = AXIS_OPACITY * (1 - t)
      }

      pose(capture ? (capturePose ?? 0) : 0)
      invalidate()
      if (capture) return

      const render = () => invalidate()

      // Intro: the assembly settles into view with a small, controlled rotation.
      if (introGroup.current) {
        gsap.fromTo(
          introGroup.current.rotation,
          { y: -0.2 },
          { y: 0, duration: MOTION.hero.introDuration, ease: MOTION.ease, onUpdate: render },
        )
        gsap.fromTo(
          introGroup.current.scale,
          { x: 0.94, y: 0.94, z: 0.94 },
          { x: 1, y: 1, z: 1, duration: MOTION.hero.introDuration, ease: MOTION.ease, onUpdate: render },
        )
      }

      const choreograph = (desktop: boolean) => {
        const trigger = desktop ? sectionEl : artEl
        const group = scrollGroup.current
        if (!trigger || !group) return

        // Assembly: parts travel along the shared axis in sequence, the ring and hex
        // turning as they seat. Short range, scrubbed, native scrolling untouched.
        const seat = { ease: MOTION.easeInOut }
        const tl = gsap.timeline({
          defaults: { ease: 'none' },
          onUpdate: render,
          scrollTrigger: desktop
            ? {
                trigger,
                start: 'top top',
                end: () => `+=${Math.round(window.innerHeight * 0.24)}`,
                scrub: MOTION.hero.scrub,
              }
            : { trigger, start: 'top 92%', end: 'bottom 30%', scrub: MOTION.hero.scrub },
        })
        tl.to(f.position, { z: L.frame.seated, duration: 0.6, ...seat }, 0)
          .to(r.position, { z: L.ring.seated, duration: 0.56, ...seat }, 0)
          .to(r.rotation, { z: 0, duration: 0.56, ...seat }, 0)
          .to(c.position, { z: L.connector.seated, duration: 0.6, ...seat }, 0.16)
          .to(c.rotation, { z: 0, duration: 0.6, ...seat }, 0.16)
          .to(p.position, { z: L.pin.seated, duration: 0.5, ...seat }, 0.42)
          .to(shift.position, { z: L.shift.seated, duration: 0.92 }, 0)
          .to(orient.scale, { x: SEATED_SCALE, y: SEATED_SCALE, z: SEATED_SCALE, duration: 0.92, ...seat }, 0)
        if (axisMaterial) tl.to(axisMaterial, { opacity: 0, duration: 0.3 }, 0.62)

        // Presentation turn across the whole hero: ~18° and a slight lift.
        const turn = { trigger, start: 'top top', end: 'bottom top', scrub: MOTION.hero.scrub }
        gsap.to(group.rotation, { y: MOTION.hero.scrollRotateRad, ease: 'none', onUpdate: render, scrollTrigger: turn })
        gsap.to(group.position, { y: 0.12, ease: 'none', onUpdate: render, scrollTrigger: { ...turn } })
      }

      const mm = gsap.matchMedia()
      mm.add(DESKTOP_QUERY, () => choreograph(true))
      mm.add(STACKED_QUERY, () => choreograph(false))
      return () => mm.revert()
    },
    { dependencies: [sectionEl, artEl, capture, capturePose, parts] },
  )

  // Ambient layer: breathing + pointer tilt, only while visible, only on fine pointers.
  useEffect(() => {
    if (capture) return
    const breath = breathGroup.current
    const tilt = pointerGroup.current
    let breathTween: gsap.core.Tween | null = null
    let removePointer = () => {}

    if (ambient && breath && tilt) {
      const travel = MOTION.hero.breathTravel
      breath.position.y = -travel / 2
      breathTween = gsap.to(breath.position, {
        y: travel / 2,
        duration: MOTION.hero.breathHalfCycle,
        ease: MOTION.ambientEase,
        yoyo: true,
        repeat: -1,
      })
      const toX = gsap.quickTo(tilt.rotation, 'x', { duration: 0.9, ease: MOTION.ease })
      const toY = gsap.quickTo(tilt.rotation, 'y', { duration: 0.9, ease: MOTION.ease })
      const max = MOTION.hero.pointerMaxRad
      const onMove = (e: PointerEvent) => {
        if (!activeRef.current || e.pointerType !== 'mouse') return
        const nx = (e.clientX / window.innerWidth) * 2 - 1
        const ny = (e.clientY / window.innerHeight) * 2 - 1
        toY(nx * max)
        toX(ny * max * 0.6)
      }
      const onLeave = () => {
        toX(0)
        toY(0)
      }
      window.addEventListener('pointermove', onMove, { passive: true })
      document.documentElement.addEventListener('pointerleave', onLeave)
      removePointer = () => {
        window.removeEventListener('pointermove', onMove)
        document.documentElement.removeEventListener('pointerleave', onLeave)
        gsap.killTweensOf(tilt.rotation)
      }
    }

    // Render driver: continuous only while ambient motion runs and the canvas is visible;
    // otherwise frames are drawn on demand by the tweens above.
    let wasActive = false
    const tick = () => {
      const active = Boolean(activeRef.current)
      if (breathTween) {
        if (active && breathTween.paused()) breathTween.resume()
        else if (!active && !breathTween.paused()) breathTween.pause()
      }
      if (active && (breathTween || !wasActive)) invalidate()
      wasActive = active
    }
    gsap.ticker.add(tick)

    return () => {
      gsap.ticker.remove(tick)
      breathTween?.kill()
      removePointer()
    }
  }, [ambient, activeRef, capture, invalidate])

  const L = PART_LAYOUT

  return (
    <group scale={fit}>
      <group ref={scrollGroup}>
        <group ref={pointerGroup}>
          <group ref={introGroup}>
            <group ref={breathGroup}>
              <group ref={orientGroup} rotation={ORIENTATION}>
                <group ref={shiftGroup} position-z={L.shift.exploded}>
                  <Line
                    ref={axis}
                    points={[
                      [0, 0, L.axis.from],
                      [0, 0, L.axis.to],
                    ]}
                    color="#234bc4"
                    lineWidth={1}
                    dashed
                    dashSize={0.2}
                    gapSize={0.09}
                    transparent
                    opacity={AXIS_OPACITY}
                  />
                  <mesh ref={frame} geometry={parts.frame} material={materials.ivory} position-z={L.frame.exploded} />
                  <mesh
                    ref={ring}
                    geometry={parts.ring}
                    material={materials.cobalt}
                    position-z={L.ring.exploded}
                    rotation-z={L.ring.spin}
                  />
                  <group ref={connector} position-z={L.connector.exploded} rotation-z={L.connector.spin}>
                    <mesh geometry={parts.collar} material={materials.steel} />
                    <mesh geometry={parts.sleeve} material={materials.steel} />
                  </group>
                  <mesh ref={pin} geometry={parts.pin} material={materials.gold} position-z={L.pin.exploded} />
                </group>
              </group>
            </group>
          </group>
        </group>
      </group>
    </group>
  )
}
