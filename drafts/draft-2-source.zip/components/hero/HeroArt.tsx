'use client'

import dynamic from 'next/dynamic'
import Image from 'next/image'
import { Component, useCallback, useEffect, useRef, useState, useSyncExternalStore, type ReactNode } from 'react'
import { DESKTOP_QUERY, FINE_POINTER_QUERY, REDUCED_MOTION_QUERY } from '@/lib/motion'
import { useMediaQuery } from '@/lib/useMediaQuery'
import { hasWebGL, prefersSaveData } from '@/lib/webgl'
import styles from './HeroArt.module.css'

const AssemblyScene = dynamic(() => import('./assembly/AssemblyScene'), { ssr: false })

const subscribeNever = () => () => {}

class SceneBoundary extends Component<{ onError: () => void; children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() {
    return { failed: true }
  }
  componentDidCatch() {
    this.props.onError()
  }
  render() {
    return this.state.failed ? null : this.props.children
  }
}

type IdleHandle = { cancel: () => void }

function whenIdle(cb: () => void): IdleHandle {
  if (typeof window.requestIdleCallback === 'function') {
    const id = window.requestIdleCallback(cb, { timeout: 900 })
    return { cancel: () => window.cancelIdleCallback(id) }
  }
  const id = window.setTimeout(cb, 120)
  return { cancel: () => window.clearTimeout(id) }
}

export function HeroArt() {
  const [artEl, setArtEl] = useState<HTMLDivElement | null>(null)
  const [near, setNear] = useState(false)
  const [ready, setReady] = useState(false)
  const [failed, setFailed] = useState(false)
  const activeRef = useRef(false)

  const reducedMotion = useMediaQuery(REDUCED_MOTION_QUERY, false)
  const desktop = useMediaQuery(DESKTOP_QUERY, true)
  const finePointer = useMediaQuery(FINE_POINTER_QUERY, true)
  const capable = useSyncExternalStore(
    subscribeNever,
    () => hasWebGL() && !prefersSaveData(),
    () => true,
  )

  const still = reducedMotion || !capable || failed
  const live = !still && near
  const sectionEl = artEl?.closest('section') ?? null

  // Load the 3D code only once the artwork is near the viewport and the main thread is idle,
  // so the headline and actions never wait for WebGL.
  useEffect(() => {
    if (!artEl || still) return
    let idle: IdleHandle | null = null
    const io = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) return
        io.disconnect()
        idle = whenIdle(() => setNear(true))
      },
      { rootMargin: '240px 0px' },
    )
    io.observe(artEl)
    return () => {
      io.disconnect()
      idle?.cancel()
    }
  }, [artEl, still])

  // Rendering pauses when the artwork is offscreen or the tab is hidden.
  useEffect(() => {
    if (!artEl) return
    let inView = false
    const update = () => {
      activeRef.current = inView && document.visibilityState === 'visible'
    }
    const io = new IntersectionObserver(([entry]) => {
      inView = Boolean(entry?.isIntersecting)
      update()
    })
    io.observe(artEl)
    document.addEventListener('visibilitychange', update)
    return () => {
      io.disconnect()
      document.removeEventListener('visibilitychange', update)
    }
  }, [artEl])

  const onReady = useCallback(() => setReady(true), [])
  const onError = useCallback(() => setFailed(true), [])

  const state = still ? 'still' : ready ? 'live' : 'loading'

  return (
    <figure className={styles.figure}>
      <div ref={setArtEl} className={styles.art} data-state={state}>
        <CropMarks />

        {still && (
          <Image
            src="/hero/assembly-still.webp"
            alt=""
            fill
            sizes="(min-width: 64rem) 45vw, 100vw"
            // Above the fold beside the headline on desktop; below the copy on phones.
            loading={desktop ? 'eager' : 'lazy'}
            className={styles.still}
          />
        )}

        {live && (
          <div className={styles.canvas} aria-hidden="true">
            <SceneBoundary onError={onError}>
              <AssemblyScene
                quality={desktop ? 'high' : 'low'}
                ambient={desktop && finePointer}
                activeRef={activeRef}
                sectionEl={sectionEl}
                artEl={artEl}
                onReady={onReady}
                onError={onError}
              />
            </SceneBoundary>
          </div>
        )}
      </div>
      <figcaption className={styles.caption}>
        <span className={styles.figNo}>Fig. 1</span>
        Four parts, one assembly: structure, motion, connection and the small detail that holds them
        together.
      </figcaption>
    </figure>
  )
}

/** Four restrained registration marks framing the drawing area. */
function CropMarks() {
  return (
    <span className={styles.crop} aria-hidden="true">
      <span />
      <span />
      <span />
      <span />
    </span>
  )
}
