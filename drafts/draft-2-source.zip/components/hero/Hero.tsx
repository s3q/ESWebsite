import type { CSSProperties } from 'react'
import { IconArrowRight } from '@/components/ui/icons'
import { HeroArt } from './HeroArt'
import styles from './Hero.module.css'

const ACTIVITIES = ['Seminars', 'Conferences', 'Exhibitions', 'Workshops']

const order = (i: number) => ({ '--i': i }) as CSSProperties

export function Hero() {
  return (
    <section id="top" className={styles.hero} aria-labelledby="hero-title">
      <div className={`container ${styles.grid}`}>
        <div className={styles.copy}>
          <p className={`${styles.eyebrow} intro-item`} style={order(0)}>
            <span className={styles.eyebrowMark} aria-hidden="true" />
            Engineering Society · Sultan Qaboos University
          </p>
          <h1 id="hero-title" className={`${styles.title} intro-item`} style={order(1)}>
            Where ideas take shape<span className={styles.stop}>.</span>
          </h1>
          <p className={`${styles.lead} intro-item`} style={order(2)}>
            Meet the people, build the projects, and discover the experiences that move your engineering journey
            forward.
          </p>
          <div className={`${styles.actions} intro-item`} style={order(3)}>
            <a href="#events" className="btn btn--primary">
              Explore Events
              <IconArrowRight className="btn__arrow" />
            </a>
            <a href="#projects" className="btn btn--secondary">
              Discover Projects
            </a>
          </div>
          {/* Keeps Draft 1's #activities anchor working. */}
          <div id="activities" className={`${styles.activities} intro-item`} style={order(4)}>
            <span className={styles.activitiesLabel}>What we run</span>
            <ul className={styles.activityList}>
              {ACTIVITIES.map((a) => (
                <li key={a}>{a}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className={styles.artColumn}>
          <HeroArt />
        </div>
      </div>
    </section>
  )
}
