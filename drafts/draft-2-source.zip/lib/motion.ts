/**
 * Motion vocabulary shared by every GSAP timeline. CSS mirrors these values in
 * styles/tokens.css (--ease-*, --dur-*). One easing family keeps the page coherent:
 * power3.out for entrances, sine.inOut for ambient loops, none for scroll scrubs.
 */
export const MOTION = {
  ease: 'power3.out',
  easeInOut: 'power2.inOut',
  ambientEase: 'sine.inOut',

  reveal: {
    duration: 0.65,
    distance: 24,
    stagger: 0.08,
    start: 'top 85%',
  },
  /** Events and Projects are for browsing: shorter travel, no per-card choreography. */
  quiet: {
    duration: 0.55,
    distance: 14,
    stagger: 0.08,
  },

  hero: {
    introDuration: 1.1,
    /** Seconds for one half of the breathing loop (full cycle ≈ 12s). */
    breathHalfCycle: 6,
    /** World units; ≈ 8px of vertical travel at the default camera. */
    breathTravel: 0.055,
    pointerMaxRad: (5 * Math.PI) / 180,
    scrollRotateRad: (18 * Math.PI) / 180,
    scrub: 0.9,
  },
} as const

export const REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)'
export const FINE_POINTER_QUERY = '(hover: hover) and (pointer: fine)'
export const DESKTOP_QUERY = '(min-width: 64rem)'
export const STACKED_QUERY = 'not all and (min-width: 64rem)'
