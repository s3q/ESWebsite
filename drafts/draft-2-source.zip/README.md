# Engineering Society — Sultan Qaboos University · Draft 2

Landing page for the Engineering Society, rebuilt on Next.js (App Router, TypeScript).
Draft 1, the Vite version, is untouched in the sibling folder `../ES`.

Product scope comes from `PRD.pdf` (Idea & Requirements Document v1.0). This is the public
landing page only: no backend, authentication or admin tools.

## Run

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # production build (includes type checking)
npm start          # serve the production build
npm run lint
npm run typecheck
```

## Page

One route, `/`, with section anchors in this order:
`#events` → `#projects` → `#impact` → `#disciplines`, then `#join` (closing invitation).
`#top` is the hero; `#activities` still works for Draft 1 links.

## What is real and what is a preview

| Area | State | Where to change it |
| --- | --- | --- |
| Events | **Sample listings**, each labelled "Sample". "Preview registration" opens an explanatory dialog; nothing is submitted. | `content/events.ts` |
| Projects | **Sample archive entries**. The discipline filter really filters them. No detail pages exist yet (`href: null`). | `content/projects.ts` |
| Impact | Qualitative, ordered by PRD phase. No statistics have been recorded, so none are shown. | `content/impact.ts` |
| Disciplines | The seven disciplines from Draft 1's content. This is not an official SQU department list. | `content/disciplines.ts` |
| Membership | No registration flow exists yet. "Join the Society" leads to `#join` and a preview dialog. | `content/site.ts` → `membershipUrl` |
| Contact / social | Draft 1's email was invented and its social links were empty, so none are shown. | `content/site.ts` → `contact` |

Setting `membershipUrl` to a real route switches the navbar and closing actions to that link.

## Structure

```
app/                 layout (fonts, metadata), page, favicon, dev-only capture route
components/
  hero/              Hero (server), HeroArt (client loader + fallbacks)
    assembly/        AssemblyScene (R3F canvas + GSAP choreography), geometry
  layout/            SiteHeader (client), SiteFooter
  sections/          Events, Projects (+ ProjectsBrowser), Impact, Disciplines, JoinInvitation
  motion/            ScrollReveals: the single GSAP ScrollTrigger reveal system
  ui/                Plate (drafting illustrations), PreviewAction (dialog), icons, art
content/             all copy and data
lib/                 motion constants, formatting, media-query + WebGL helpers
styles/              tokens.css (colour, type, space, motion), globals.css
```

Server Components are the default. Client Components cover the navbar, the 3D scene, the
project filter, dialogs and the reveal system.

## Motion and 3D

- **Hero assembly:** Three.js via React Three Fiber renders four parts (ivory plate, cobalt
  flange ring, steel hex connector, gold pin). GSAP animates them: the parts start as an
  exploded view and seat together over a short, scrubbed scroll range. The hero also has a
  small intro rotation, an ~18° presentation turn across the hero, and, on fine-pointer
  desktops only, ±5° pointer tilt and a 12-second breathing loop. Intro, pointer, breathing
  and scroll each move a different parent group.
- **Loading:** the scene is imported with `next/dynamic` (`ssr: false`) only once the
  artwork nears the viewport and the browser is idle. Canvas resolution is capped (2× desktop,
  1.5× mobile). Rendering is on demand and stops when the canvas is offscreen or the tab
  is hidden. Mobile uses lighter geometry and no ambient motion.
- **Fallbacks:** reduced motion, Save-Data, missing WebGL, a render error or a lost GPU
  context all show `public/hero/assembly-still.webp`. That image is a render of the real
  scene, regenerated with `scripts/capture-still.mjs`. Under reduced motion the 3D code is
  never downloaded.
- **Everything else:** hero text enters with a CSS animation that starts before
  hydration. Section reveals use GSAP ScrollTrigger once, at 85% of viewport height. Events
  and Projects use a shorter travel distance. Content is visible without JavaScript.

## Design skills

Installed at project scope in `.claude/skills` (see `skills-lock.json`): Emil Kowalski's
skills, Hallmark, and UI UX Pro Max. The design stamp at the top of `styles/tokens.css` and
`.hallmark/log.json` record the Hallmark choices.
